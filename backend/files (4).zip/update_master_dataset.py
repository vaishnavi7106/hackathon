"""
Layer 2 — Incremental Master Dataset
=====================================
new_data = fetch_api()
master   = concat(master, new_data)
remove_duplicates()
save()

Exactly your spec. Reads the pointer file written by fetch_latest_data.py,
concats onto the persistent master, dedupes on the natural key, saves.
This is the ONLY place the master CSV is written — never rebuild it from
scratch on a daily run.

Usage:
  python update_master_dataset.py
"""
import os
from pathlib import Path

import pandas as pd

RAW_INCOMING_DIR = Path(os.environ.get("RAW_INCOMING_DIR",
                         r"C:\Users\amizh\Downloads\pillar3\raw_incoming"))
MASTER_FILE = Path(os.environ.get("MASTER_FILE",
                    r"C:\Users\amizh\Downloads\pillar3\combined_all_tamil_nadu.csv"))

KEY_COLS = ["Arrival_Date", "District", "Market", "Commodity", "Variety"]


def main():
    new_path = RAW_INCOMING_DIR / "_latest.csv"
    if not new_path.exists():
        print(f"No incoming file at {new_path} — run fetch_latest_data.py first.")
        return

    new_data = pd.read_csv(new_path, low_memory=False)
    new_data["Arrival_Date"] = pd.to_datetime(new_data["Arrival_Date"], errors="coerce")
    print(f"Incoming: {len(new_data):,} rows")

    if MASTER_FILE.exists():
        master = pd.read_csv(MASTER_FILE, low_memory=False)
        master["Arrival_Date"] = pd.to_datetime(master["Arrival_Date"], errors="coerce")
        before = len(master)
    else:
        master = pd.DataFrame(columns=new_data.columns)
        before = 0

    combined = pd.concat([master, new_data], ignore_index=True)

    combined["_key"] = combined[KEY_COLS].astype(str).agg("|".join, axis=1)
    n_before_dedup = len(combined)
    combined = combined.drop_duplicates(subset="_key", keep="last").drop(columns=["_key"])

    print(f"Master before: {before:,} rows")
    print(f"After concat : {n_before_dedup:,} rows")
    print(f"After dedup  : {len(combined):,} rows  "
          f"({n_before_dedup - len(combined):,} duplicates removed)")

    MASTER_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = MASTER_FILE.with_suffix(".tmp.csv")
    combined.to_csv(tmp_path, index=False)
    tmp_path.replace(MASTER_FILE)  # atomic swap
    print(f"Saved master -> {MASTER_FILE}")


if __name__ == "__main__":
    main()
