"""
Layer 1 — Daily Data Ingestion
================================
Pulls the trailing N days from the AGMARKNET API and writes a dated
raw file. Does NOT touch the master dataset — that's update_master_dataset.py.
Keeping fetch and merge as separate scripts (per your layer split) means
you can re-run a fetch without risk of double-merging, and keep raw
API dumps for audit/debug.

Usage:
  python fetch_latest_data.py
  python fetch_latest_data.py --lookback-days 10
"""
import argparse
import os
import time
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import requests

API_BASE = "https://api.data.gov.in/resource/35985678-0d79-46b4-9ed6-6f13308a1d24"
PAGE_LIMIT = 1000

FIELD_MAP = {
    "state": "State", "district": "District", "market": "Market",
    "commodity": "Commodity", "variety": "Variety", "grade": "Grade",
    "arrival_date": "Arrival_Date", "min_price": "Min_Price",
    "max_price": "Max_Price", "modal_price": "Modal_Price",
    "commodity_code": "Commodity_Code",
}

RAW_INCOMING_DIR = Path(os.environ.get("RAW_INCOMING_DIR",
                         r"C:\Users\amizh\Downloads\pillar3\raw_incoming"))


def fetch_all(api_key, state):
    records, offset = [], 0
    while True:
        params = {"api-key": api_key, "format": "json", "offset": offset,
                  "limit": PAGE_LIMIT, "filters[State]": state}
        r = requests.get(API_BASE, params=params, timeout=30)
        r.raise_for_status()
        page = r.json().get("records", [])
        if not page:
            break
        records.extend(page)
        offset += PAGE_LIMIT
        time.sleep(0.3)
    return pd.DataFrame(records)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--state", default="Tamil Nadu")
    ap.add_argument("--lookback-days", type=int, default=10,
                     help="Overlap with previous fetches is fine — "
                          "dedup happens in update_master_dataset.py")
    args = ap.parse_args()

    api_key = os.environ["AGMARKNET_API_KEY"]
    RAW_INCOMING_DIR.mkdir(parents=True, exist_ok=True)

    print(f"Fetching state={args.state}, lookback={args.lookback_days}d...")
    raw = fetch_all(api_key, args.state)
    print(f"  Fetched {len(raw):,} raw records")

    if raw.empty:
        print("No records returned.")
        return

    raw = raw.rename(columns=FIELD_MAP)
    raw["Arrival_Date"] = pd.to_datetime(raw["Arrival_Date"], dayfirst=True, errors="coerce")
    cutoff = datetime.now() - timedelta(days=args.lookback_days)
    raw = raw[raw["Arrival_Date"] >= cutoff]

    keep_cols = [c for c in FIELD_MAP.values() if c in raw.columns]
    raw = raw[keep_cols]

    out_path = RAW_INCOMING_DIR / f"raw_{datetime.now():%Y%m%d_%H%M%S}.csv"
    raw.to_csv(out_path, index=False)
    print(f"Saved {len(raw):,} rows -> {out_path}")

    # Always-current pointer for the next stage to read without globbing
    latest_path = RAW_INCOMING_DIR / "_latest.csv"
    raw.to_csv(latest_path, index=False)
    print(f"Updated pointer -> {latest_path}")


if __name__ == "__main__":
    main()
