"""
predict.py — Backend-facing prediction interface
====================================================
Given (district, commodity), loads the latest engineered feature row
from live_features.csv (produced daily by build_features.py --mode serve)
and the saved per-horizon models, returns predictions for horizons
1, 3, 7, 14 days (21/30 dropped per your note).

Designed to be imported directly by your existing backend:

    from predict import predict

    result = predict("Coimbatore", "Tomato")
    # {"district": "Coimbatore", "commodity": "Tomato",
    #  "as_of": "2026-06-20",
    #  "predictions": {"1d": 1842.3, "3d": 1790.1, "7d": 1755.0, "14d": 1820.4},
    #  "model_version": "2026-06-01"}

Or run standalone for a quick CLI check:
  python predict.py --district Coimbatore --commodity Tomato
"""
import argparse
import json
import os
import pickle
from pathlib import Path

import pandas as pd

ROOT = Path(os.environ.get("PIPELINE_ROOT", r"C:\Users\amizh\Downloads\pillar3"))
LIVE_FEATURES_FILE = ROOT / "live" / "live_features.csv"
MODELS_ROOT = Path(os.environ.get("MODELS_ROOT", ROOT / "models_final" / "models_all_horizons"))

HORIZONS = [1, 3, 7, 14]  # 21d/30d dropped per current model set


def safe_name(commodity: str) -> str:
    return (
        commodity.lower()
        .replace("(", "").replace(")", "")
        .replace(" ", "_").replace("-", "_").replace("/", "_")
    )


_feature_cache = None


def _load_live_features():
    global _feature_cache
    if _feature_cache is None:
        if not LIVE_FEATURES_FILE.exists():
            raise FileNotFoundError(
                f"{LIVE_FEATURES_FILE} not found — run "
                f"`build_features.py --mode serve` first (daily job)."
            )
        _feature_cache = pd.read_csv(LIVE_FEATURES_FILE, parse_dates=["Arrival_Date"],
                                      low_memory=False)
    return _feature_cache


def _load_model(commodity, horizon):
    cname = safe_name(commodity)
    h_label = f"h{horizon}d"
    model_path = MODELS_ROOT / cname / h_label / f"{cname}_{h_label}_model.pkl"
    params_path = MODELS_ROOT / cname / h_label / f"{cname}_{h_label}_best_params.json"
    if not model_path.exists():
        return None, None
    with open(model_path, "rb") as f:
        model = pickle.load(f)
    with open(params_path) as f:
        params = json.load(f)
    return model, params


def predict(district: str, commodity: str) -> dict:
    df = _load_live_features()
    row = df[(df["District"] == district) & (df["Commodity"] == commodity)]

    if row.empty:
        return {
            "district": district, "commodity": commodity,
            "error": f"No live feature row found for ({district}, {commodity}). "
                     f"Check spelling matches AGMARKNET naming, or this group "
                     f"may have insufficient recent data.",
        }

    row = row.sort_values("Arrival_Date").tail(1)
    as_of = row["Arrival_Date"].iloc[0]

    predictions = {}
    for h in HORIZONS:
        model, params = _load_model(commodity, h)
        if model is None:
            predictions[f"{h}d"] = None
            continue
        features = params["features_used"]
        missing = [f for f in features if f not in row.columns]
        if missing:
            predictions[f"{h}d"] = None
            continue
        pred = model.predict(row[features])[0]
        predictions[f"{h}d"] = round(float(pred), 2)

    return {
        "district": district,
        "commodity": commodity,
        "as_of": str(as_of.date()),
        "predictions": predictions,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--district", required=True)
    ap.add_argument("--commodity", required=True)
    args = ap.parse_args()
    print(json.dumps(predict(args.district, args.commodity), indent=2))


if __name__ == "__main__":
    main()
